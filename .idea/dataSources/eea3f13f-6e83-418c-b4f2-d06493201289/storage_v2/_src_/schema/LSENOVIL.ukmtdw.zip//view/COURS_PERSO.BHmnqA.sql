create view COURS_PERSO as
(SELECT formation.idform, formation.nomform,cours.coefficient,enseignant.nom_ens,enseignant.prenom_ens 
FROM enseignant,formation,cours
WHERE cours.idform = formation.idform
AND enseignant.login_ens = cours.login_ens)
/

