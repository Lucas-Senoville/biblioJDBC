create view NOTES_PROFS as
(SELECT cours.login_ens,cours.idcours,resultat.ds 
from cours, resultat 
where cours.idcours = resultat.idcours 
AND cours.login_ens = user)
/

