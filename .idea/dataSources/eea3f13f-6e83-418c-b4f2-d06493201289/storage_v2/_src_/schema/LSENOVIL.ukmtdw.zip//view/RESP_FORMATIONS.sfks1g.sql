create view RESP_FORMATIONS as
select formation.nomform,enseignant.login_ens,enseignant.nom_ens from formation,enseignant
/

