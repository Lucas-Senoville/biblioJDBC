create view RESULTAT_PERSO as
select "LOGIN_ET","IDCOURS","DS","CC" from resultat where login_et=user
/

