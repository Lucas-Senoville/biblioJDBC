create trigger COMPARAISONDATE
    before insert or update
    on PRICE
    for each row
Declare
  prix  float(4);
Begin 
  if :enddate :=null 
  then
    prix :=stdprice;
    dbms_output.putline('Voici le prix '||prix);
   end if;
  commit;
end;
/

