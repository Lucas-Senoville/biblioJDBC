create view QQTÉPARMOIS as
SELECT product.descrip description,SUM(item.ITEMTOT)Total ,TO_CHAR(ORDERDATE, 'Month') Mois
FROM item , product , ord 
WHERE item.ordid = ord.ordid and product.PRODID = item.PRODID
GROUP BY TO_CHAR(ORDERDATE, 'Month'),TO_CHAR(ORDERDATE, 'MM'),product.descrip
/

