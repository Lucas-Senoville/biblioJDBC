create view PAY as
(SELECT ENAME, SAL as Mensuel, SAL*12 as Annuel, DEPTNO FROM EMP)
/

