create trigger CLEMSGNEWSGROUP
    before insert
    on MESSAGE
    for each row
begin
select idm.nextval into :new.idmessage  from dual;
end;
/

