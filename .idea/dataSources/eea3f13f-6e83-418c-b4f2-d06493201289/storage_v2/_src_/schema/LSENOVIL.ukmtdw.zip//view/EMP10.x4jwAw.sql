create view EMP10 as
(SELECT DEPTNO, EMPNO, ENAME, JOB from EMP 
where DEPTNO = 10 )
/

