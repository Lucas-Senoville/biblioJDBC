create view RESULTAT_PROF as
select "LOGIN_ET","IDCOURS","DS","CC" from resultat
/

