create view DEPT_SAL as
(SELECT DEPTNO, MIN(SAL) as Minimum,MAX(SAL) as Maximum,AVG(SAL) as Moyenne,SUM(SAL) as Somme from EMP GROUP BY DEPTNO)
/

