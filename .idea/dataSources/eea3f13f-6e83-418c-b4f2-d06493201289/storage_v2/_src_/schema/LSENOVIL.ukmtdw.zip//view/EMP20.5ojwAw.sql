create view EMP20 as
(SELECT "EMPNO","ENAME","JOB","MGR","HIREDATE","SAL","COMM","DEPTNO","PNUM" FROM Emp WHERE deptno = 20)
/

